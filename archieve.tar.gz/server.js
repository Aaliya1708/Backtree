const express = require('express');
const puppeteer = require('puppeteer');
const fs=require('fs');
const app = express();
const port = 3000;

const searchGoogle = require('./searchGoogle');

app.get('/search', (request, response) => {
    const searchQuery = request.query.searchquery;
    if(searchQuery != null)
    {
        searchGoogle(searchQuery)
        .then(results => {
            response.status(200);
            response.json(results);
        });
    }
    else
    {
      response.end();
    }
  
});

app.get('/', (req, res) => {
    fs.readFile("google.html",function(err,data){
      if(err){
          res.writeHead(404,{'Content-Type': 'text/html'});
          return res.end("404 Not Found");
      }
      res.writeHead(200,{'Content-Type': 'text/html'});
      res.write(data);
      return res.end();
    });

});


app.listen(port, () => console.log(`Example app listening on port ${port}! \n connect at http://localhost:${port}/`));



