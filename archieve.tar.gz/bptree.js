var MAX = 4;

// BP node
class Node {
    constructor(ind) {
        this.key = new Array(MAX);
        this.ptr = new Array(MAX + 1);
        this.IS_LEAF = false;
        this.size = new Array();
        //console.log(ind);
        this.ind = ind;
    }
};

// BP tree
class BPTree {
    constructor(){
        this.root = null;
        this.numele = 0;
    }
    static insertInternal;
    static findParent;

    static search;
    static insert;
    static display;
    static getRoot;
};

// Search operation
BPTree.prototype.search = function(x) {
  if (this.root == null) {
    console.log("Tree is empty\n");
  } else {
    var cursor = this.root;
    while (cursor.IS_LEAF == false) {
      for (var i = 0; i < cursor.size; i++) {
        if (x < cursor.key[i]) {
          cursor = cursor.ptr[i];
          break;
        }
        if (i == cursor.size - 1) {
          cursor = cursor.ptr[i + 1];
          break;
        }
      }
    }
    for (var i = 0; i < cursor.size; i++) {
      if (cursor.key[i] == x) {
        console.log("Found\n");
        return;
      }
    }
    console.log("Not found\n");
  }
}

// Insert Operation
BPTree.prototype.insert = function(x) {
  if (this.root == null) {
    this.root = new Node(this.numele++); 
    this.root.key[0] = x;
    this.root.IS_LEAF = true;
    this.root.size = 1;
  } else {
    var cursor = this.root;
    var parent;
    while (cursor.IS_LEAF == false) {
      parent = cursor;
      for (var i = 0; i < cursor.size; i++) {
        if (x < cursor.key[i]) {
          cursor = cursor.ptr[i];
          break;
        }
        if (i == cursor.size - 1) {
          cursor = cursor.ptr[i + 1];
          break;
        }
      }
    }
    if (cursor.size < MAX) {
      var i = 0;
      while (x > cursor.key[i] && i < cursor.size)
        i++;
      for (var j = cursor.size; j > i; j--) {
        cursor.key[j] = cursor.key[j - 1];
      }
      cursor.key[i] = x;
      cursor.size++;
      cursor.ptr[cursor.size] = cursor.ptr[cursor.size - 1];
      cursor.ptr[cursor.size - 1] = null;
    } else {
      var newLeaf = new Node(this.numele++);
      var virtualNode = new Array(MAX + 1);
      for (var i = 0; i < MAX; i++) {
        virtualNode[i] = cursor.key[i];
      }
      var i = 0;
      var j;
      while (x > virtualNode[i] && i < MAX)
        i++;
      for (var j = MAX + 1; j > i; j--) {
        virtualNode[j] = virtualNode[j - 1];
      }
      virtualNode[i] = x;
      newLeaf.IS_LEAF = true;
      cursor.size = (MAX + 1) / 2;
      newLeaf.size = MAX + 1 - (MAX + 1) / 2;
      cursor.ptr[cursor.size] = newLeaf;
      newLeaf.ptr[newLeaf.size] = cursor.ptr[MAX];
      cursor.ptr[MAX] = null;
      for (var i = 0; i < cursor.size; i++) {
        cursor.key[i] = virtualNode[i];
      }
      for (var i = 0, j = cursor.size; i < newLeaf.size; i++, j++) {
        newLeaf.key[i] = virtualNode[j];
      }
      if (cursor == this.root) {
        var newRoot = new Node(this.numele++);
        newRoot.key[0] = newLeaf.key[0];
        newRoot.ptr[0] = cursor;
        newRoot.ptr[1] = newLeaf;
        newRoot.IS_LEAF = false;
        newRoot.size = 1;
        this.root = newRoot;
      } else {
        this.insertInternal(newLeaf.key[0], parent, newLeaf);
      }
    }
  }
}

// Insert Operation
BPTree.prototype.insertInternal = function(x,cursor,child) {
  if (cursor.size < MAX) {
    var i = 0;
    while (x > cursor.key[i] && i < cursor.size)
      i++;
    for (var j = cursor.size; j > i; j--) {
      cursor.key[j] = cursor.key[j - 1];
    }
    for (var j = cursor.size + 1; j > i + 1; j--) {
      cursor.ptr[j] = cursor.ptr[j - 1];
    }
    cursor.key[i] = x;
    cursor.size++;
    cursor.ptr[i + 1] = child;
  } else {
    var newInternal = new Node(this.numele++);
    var virtualKey = Array(MAX + 1);
    var virtualPtr = Array(MAX + 2);
    for (var i = 0; i < MAX; i++) {
      virtualKey[i] = cursor.key[i];
    }
    for (var i = 0; i < MAX + 1; i++) {
      virtualPtr[i] = cursor.ptr[i];
    }
    var i = 0;
    var j;
    while (x > virtualKey[i] && i < MAX)
      i++;
    for (var j = MAX + 1; j > i; j--) {
      virtualKey[j] = virtualKey[j - 1];
    }
    virtualKey[i] = x;
    for (var j = MAX + 2; j > i + 1; j--) {
      virtualPtr[j] = virtualPtr[j - 1];
    }
    virtualPtr[i + 1] = child;
    newInternal.IS_LEAF = false;
    cursor.size = (MAX + 1) / 2;
    newInternal.size = MAX - (MAX + 1) / 2;
    for (var i = 0, j = cursor.size + 1; i < newInternal.size; i++, j++) {
      newInternal.key[i] = virtualKey[j];
    }
    for (var i = 0, j = cursor.size + 1; i < newInternal.size + 1; i++, j++) {
      newInternal.ptr[i] = virtualPtr[j];
    }
    if (cursor == this.root) {
      var newRoot = new Node(this.numele++);
      newRoot.key[0] = cursor.key[cursor.size];
      newRoot.ptr[0] = cursor;
      newRoot.ptr[1] = newInternal;
      newRoot.IS_LEAF = false;
      newRoot.size = 1;
      this.root = newRoot;
    } else {
      insertInternal(cursor.key[cursor.size], findParent(this.root, cursor), newInternal);
    }
  }
}

// Find the parent
BPTree.prototype.findParent =  function(cursor,child) {
  var parent;
  if (cursor.IS_LEAF || (cursor.ptr[0]).IS_LEAF) {
    return null;
  }
  for (var i = 0; i < cursor.size + 1; i++) {
    if (cursor.ptr[i] == child) {
      parent = cursor;
      return parent;
    } else {
      parent = this.findParent(cursor.ptr[i], child);
      if (parent != null)
        return parent;
    }
  }
  return parent;
}

// Print the tree
BPTree.prototype.display = function(cursor) {
  if (cursor != null) {
    console.log("$"+cursor.ind+"$");
    for (var i = 0; i < cursor.size; i++) {
      console.log(cursor.key[i]);
    }
    if (cursor.IS_LEAF != true) {
      for (var i = 0; i < cursor.size + 1; i++) {
        this.display(cursor.ptr[i]);
      }
    }
  }
}

// Get the root
BPTree.prototype.getRoot = function() {
  return this.root;
}

var main = function() {
  var node = new BPTree();
  inp = Array(5,15,25,35,45,55,40,30,20,64,1,75,2,88,3,66,777);
  for(val of inp){
    node.insert(val);
  }
  /*
  node.insert(5);
  node.insert(15);
  node.insert(25);
  node.insert(35);
  node.insert(45);
  node.insert(55);
  node.insert(40);
  node.insert(30);
  node.insert(20);
  */
  node.display(node.getRoot());

  node.search(15);
  node.search(115);
}

main();
